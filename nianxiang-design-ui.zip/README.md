# 念 UI 设计稿

| 文件 | 说明 |
|---|---|
| `niannian-demo.html` | 可点的 Android Demo（412×892），浏览器直接打开；对话为本地规则模拟 |
| `design.md` | 设计规范 v0.2（Android 主，iOS 对齐） |
| `svg/` | Demo 每个状态导出的 40 页 SVG，可拖进 Figma 编辑 |

在线预览 Demo：<https://htmlpreview.github.io/?https://github.com/gzmakes/nianxiang/blob/ui/design/niannian-demo.html>

在线画布（需分享后可见）：
- 念念 设计规范 v0.2：https://claude.ai/artifact/YZ3NhxjYhKUw55npFqpYSM
- 念念 Android 线框图：https://claude.ai/artifact/P2fkX3q4vVYn5WtsB1Fexx
